When you open the an agent implementation project do not forget to update the GeometryFriends dependency (see References in the Project Explorer)

This reference is the GeometryFriends.exe.